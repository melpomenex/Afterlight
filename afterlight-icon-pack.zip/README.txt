Afterlight Icon Pack
====================

Included:
- favicon.ico (multi-resolution)
- favicon-16x16.png
- favicon-32x32.png
- favicon-48x48.png
- favicon-64x64.png
- icon-96x96.png
- icon-128x128.png
- apple-touch-icon.png (180x180)
- pwa-192x192.png
- pwa-256x256.png
- pwa-384x384.png
- pwa-512x512.png
- maskable-192x192.png
- maskable-512x512.png
- mstile-150x150.png
- site.webmanifest
- browserconfig.xml
- head-snippet.html
- source-icon.png

Suggested placement:
Copy the files into your app's public/ directory (or equivalent static asset root).

The maskable icons include extra safe-area padding so launchers can crop them into circles,
squircles, rounded rectangles, or other adaptive icon shapes without cutting off the artwork.
